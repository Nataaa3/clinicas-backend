package com.example.nataliaweb.controllers;

@RestController
@RequestMapping("/api/clinicas")
@CrossOrigin(origins = "*")
public class ClinicaController {

    private final ClinicaService clinicaService;

    public ClinicaController(ClinicaService clinicaService) {
        this.clinicaService = clinicaService;
    }

    @GetMapping
    public List<ClinicaDTO> listar() {
        return clinicaService.listarTodas();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ClinicaDTO crear(@RequestBody ClinicaDTO dto) {
        return clinicaService.crear(dto);
    }
}
