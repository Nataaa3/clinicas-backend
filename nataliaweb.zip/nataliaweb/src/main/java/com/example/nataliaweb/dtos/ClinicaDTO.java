package com.example.nataliaweb.dtos;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ClinicaDTO {

    private String identificador;
    private String nombre;
    private String direccion;
    private Integer cantidadCamas;
    private String telefono;
    private String ciudad;
    private LocalDate fechaCreacion;
}
