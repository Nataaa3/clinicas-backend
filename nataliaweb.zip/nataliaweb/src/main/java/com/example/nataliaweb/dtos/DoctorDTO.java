package com.example.nataliaweb.dtos;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DoctorDTO {

    private Long id;
    private String nombre;
    private String especialidad;
    private String clinicaId;

    private String email;
    private String telefono;
    private LocalDate fechaContratacion;
}