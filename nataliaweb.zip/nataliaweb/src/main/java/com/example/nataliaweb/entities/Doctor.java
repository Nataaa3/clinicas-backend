package com.example.nataliaweb.entities;

Entity
@Table(name = "doctores")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Doctor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;  // PK

    private String nombre;
    private String especialidad;

    // FK hacia clínica
    @ManyToOne
    @JoinColumn(name = "clinica_id")
    private Clinica clinica;

    private String email;
    private String telefono;

    @Column(name = "fecha_contratacion")
    private LocalDate fechaContratacion;
}
