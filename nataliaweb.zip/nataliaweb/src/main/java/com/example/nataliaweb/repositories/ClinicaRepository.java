package com.example.nataliaweb.repositories;

public interface ClinicaRepository extends JpaRepository<Clinica, String> {
}
