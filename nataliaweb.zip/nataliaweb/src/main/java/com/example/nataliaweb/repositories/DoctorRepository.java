package com.example.nataliaweb.repositories;

public interface DoctorRepository extends JpaRepository<Doctor, Long> {
}
