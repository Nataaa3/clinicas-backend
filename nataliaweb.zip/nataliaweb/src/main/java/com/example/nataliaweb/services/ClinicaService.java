package com.example.nataliaweb.services;

@Service
public class ClinicaService {

    private final ClinicaRepository clinicaRepository;
    private final ModelMapper modelMapper;

    public ClinicaService(ClinicaRepository clinicaRepository, ModelMapper modelMapper) {
        this.clinicaRepository = clinicaRepository;
        this.modelMapper = modelMapper;
    }

    public List<ClinicaDTO> listarTodas() {
        return clinicaRepository.findAll()
                .stream()
                .map(c -> modelMapper.map(c, ClinicaDTO.class))
                .collect(Collectors.toList());
    }

    public ClinicaDTO crear(ClinicaDTO dto) {
        Clinica entidad = modelMapper.map(dto, Clinica.class);
        Clinica guardada = clinicaRepository.save(entidad);
        return modelMapper.map(guardada, ClinicaDTO.class);
    }
}
