package com.example.nataliaweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NataliawebApplicationTests {

	@Test
	void contextLoads() {
	}

}
